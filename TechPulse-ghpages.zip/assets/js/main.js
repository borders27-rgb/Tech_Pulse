
import { settings, saveSettings, watchlist, alerts, saveAlerts } from './store.js';
import { groupTrends, noveltyScore } from './analyzers.js';
import { fetchAllEnabledSources, getAlphaPrices } from './connectors.js';
import { renderTrendCards, renderFeed, renderWatchlist, renderAlerts, bindChrome } from './ui.js';

const state = {
  articles: [],
  trends: [],
  prices: window.MOCK_PRICES || {},
  view: 'trends',
  filteredFeed: []
};

async function hydratePrices() {
  // Try Alpha Vantage for each watchlist ticker if key is present; else use mock
  if (!settings.alphaKey) return;
  for (const tk of watchlist) {
    try {
      const series = await getAlphaPrices(tk);
      if (series && series.length) state.prices[tk] = series;
    } catch (e) {
      console.warn('Price fetch failed for', tk, e);
    }
  }
}

async function loadArticles() {
  if (settings.demoMode) {
    state.articles = (window.MOCK_ARTICLES || []).slice().sort((a,b)=>new Date(b.publishedAt)-new Date(a.publishedAt));
  } else {
    const items = await fetchAllEnabledSources();
    state.articles = items.sort((a,b)=>new Date(b.publishedAt)-new Date(a.publishedAt));
  }
  state.trends = groupTrends(state.articles).sort((a,b)=>noveltyScore(b)-noveltyScore(a));
  state.filteredFeed = state.articles;
}

function applySearch(q) {
  q = (q || '').trim().toLowerCase();
  if (!q) {
    state.filteredFeed = state.articles;
  } else {
    state.filteredFeed = state.articles.filter(a =>
      (a.title||'').toLowerCase().includes(q) ||
      (a.summary||'').toLowerCase().includes(q) ||
      (a.content||'').toLowerCase().includes(q) ||
      (a.source||'').toLowerCase().includes(q));
  }
  renderFeed(state.filteredFeed);
}

function sortTrends(mode='novelty') {
  if (mode === 'novelty') state.trends.sort((a,b)=>noveltyScore(b)-noveltyScore(a));
  if (mode === 'mentions') state.trends.sort((a,b)=>b.items.length - a.items.length);
  if (mode === 'recent') state.trends.sort((a,b)=> new Date(b.items[0].publishedAt) - new Date(a.items[0].publishedAt) );
}

function bindSort() {
  const sel = document.getElementById('trendSort');
  sel.addEventListener('change', () => {
    sortTrends(sel.value);
    renderTrendCards(state.trends);
  });
}

async function refresh() {
  await loadArticles();
  await hydratePrices();
  renderTrendCards(state.trends);
  renderFeed(state.filteredFeed);
  renderAlerts();
  renderWatchlist(state.prices);
}

function toggleDemo() {
  settings.demoMode = !settings.demoMode; saveSettings();
  document.getElementById('demoBtn').textContent = settings.demoMode ? 'Demo data' : 'Live mode';
  refresh();
}

function runAlerts() {
  // Evaluate simple rules and show a toast
  const results = [];
  for (const al of alerts) {
    let ok = false, note = '';
    if (al.rule.type === 'noveltyAbove') {
      const top = state.trends[0] ? noveltyScore(state.trends[0]) : 0;
      ok = top >= (al.rule.threshold || 80);
      note = `Top novelty=${top}`;
    } else if (al.rule.type === 'priceJumpPct') {
      const tk = al.rule.ticker;
      const s = state.prices[tk] || [];
      if (s.length >= 2) {
        const last = s[s.length-1], prev = s[s.length-2];
        const pct = ((last - prev) / prev) * 100;
        ok = Math.abs(pct) >= (al.rule.pct || 3);
        note = `${tk} Δ=${pct.toFixed(2)}%`;
      } else {
        note = `${tk} no data`;
      }
    }
    results.push({ id: al.id, ok, note });
  }
  alert('Alert check complete:\n' + results.map(r => `${r.id}: ${r.ok ? 'TRIGGERED' : 'ok'} — ${r.note}`).join('\n'));
}

function createAlert() {
  const type = prompt('Alert type? ("noveltyAbove" or "priceJumpPct")');
  if (!type) return;
  let rule = { type };
  if (type === 'noveltyAbove') {
    const th = Number(prompt('Novelty threshold (0–100)?', '75') || '75');
    rule.threshold = th;
  } else if (type === 'priceJumpPct') {
    const tk = (prompt('Ticker (e.g., NVDA)?', 'NVDA')||'').toUpperCase();
    const pct = Number(prompt('Absolute % move threshold?', '3') || '3');
    rule.ticker = tk; rule.pct = pct;
  } else {
    alert('Unknown type');
    return;
  }
  alerts.push({ id: 'alrt' + (Date.now()%100000), rule, active: true });
  saveAlerts();
  renderAlerts();
}

const app = {
  refresh,
  toggleDemo,
  onSearch: applySearch,
  runAlerts,
  createAlert
};

window.addEventListener('DOMContentLoaded', () => {
  bindChrome(app);
  bindSort();
  refresh();
});
