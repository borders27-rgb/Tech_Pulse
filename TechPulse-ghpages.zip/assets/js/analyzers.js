
import { settings } from './store.js';

const STOP = new Set('a an the to of and for with in on at from by is are was were this that it they them we our you your as be have has had do does did via vs into across using about over with'.split(' '));

function tokenize(txt) {
  return (txt || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s\-]/g, ' ')
    .split(/\s+/)
    .filter(w => w && !STOP.has(w) && w.length > 2);
}

function extractKeywords(docs, topN=10) {
  const df = new Map();
  const tf = docs.map(d => {
    const counts = new Map();
    const uniq = new Set();
    tokenize((d.title||'') + ' ' + (d.summary||'') + ' ' + (d.content||'')).forEach(w => {
      counts.set(w, (counts.get(w) || 0) + 1);
      uniq.add(w);
    });
    uniq.forEach(w => df.set(w, (df.get(w) || 0) + 1));
    return counts;
  });
  const N = docs.length;
  const scored = new Map();
  tf.forEach(counts => {
    counts.forEach((c, w) => {
      const idf = Math.log(1 + N / (1 + (df.get(w) || 1)));
      const s = c * idf;
      scored.set(w, (scored.get(w) || 0) + s);
    });
  });
  return [...scored.entries()].sort((a,b) => b[1]-a[1]).slice(0, topN).map(([k]) => k);
}

function detectTickers(txt) {
  const t = new Set();
  (txt || '').replace(/\b[A-Z]{1,5}\b/g, (m) => { t.add(m); });
  return [...t];
}

function groupTrends(articles) {
  const items = articles.map(a => ({
    ...a,
    keywords: extractKeywords([a], 5),
    detectedTickers: detectTickers(((a.title||'') + ' ' + (a.summary||'') + ' ' + (a.content||'')))
  }));

  // Build clusters by concept/keyword overlap
  const clusters = [];
  for (let i=0;i<items.length;i++) {
    const ai = items[i];
    let placed = false;
    for (const c of clusters) {
      const overlap = ai.keywords.filter(k => c.keywords.has(k)).length +
                      (ai.concepts||[]).filter(x => c.concepts.has(x.toLowerCase())).length;
      if (overlap >= 2) {
        c.items.push(ai);
        ai.keywords.forEach(k => c.keywords.add(k));
        (ai.concepts||[]).forEach(x => c.concepts.add(x.toLowerCase()));
        (ai.tickers||[]).forEach(t => c.tickers.add(t));
        (ai.detectedTickers||[]).forEach(t => c.tickers.add(t));
        placed = true; break;
      }
    }
    if (!placed) {
      const kw = new Set(ai.keywords);
      const cc = new Set((ai.concepts||[]).map(x => x.toLowerCase()));
      const tk = new Set([...(ai.tickers||[]), ...(ai.detectedTickers||[])]);
      clusters.push({ id: 'tr'+(clusters.length+1), keywords: kw, concepts: cc, tickers: tk, items: [ai] });
    }
  }
  return clusters.map(c => ({
    id: c.id,
    label: [...c.concepts].slice(0,2).join(' • ') || [...c.keywords].slice(0,3).join(' '),
    keywords: [...c.keywords],
    concepts: [...c.concepts],
    tickers: [...c.tickers],
    items: c.items
  }));
}

function noveltyScore(trend) {
  const now = Date.now();
  const times = trend.items.map(i => new Date(i.publishedAt).getTime());
  const recency = Math.max(0, 1 - (now - Math.max(...times)) / (1000*60*60*48)); // within 48h
  const velocity = trend.items.length > 1 ? Math.min(1, (trend.items.length-1) / 6) : 0.15; // crude
  const diversity = new Set(trend.items.map(i => i.source)).size / Math.max(1, trend.items.length);
  const base = 0.45*recency + 0.35*velocity + 0.20*diversity;
  return Math.round(100 * Math.max(0, Math.min(1, base)));
}

async function analyzeWithLLM(text) {
  if (!settings.llmEndpoint || !settings.llmKey) return null;
  try {
    const res = await fetch(settings.llmEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + settings.llmKey
      },
      body: JSON.stringify({ input: text })
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data; // expect { concepts:[], companies:[], summary:"" } etc.
  } catch(e) {
    console.warn('LLM error', e);
    return null;
  }
}

export { extractKeywords, detectTickers, groupTrends, noveltyScore, analyzeWithLLM };
