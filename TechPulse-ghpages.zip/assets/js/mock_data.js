window.MOCK_ARTICLES = [
  {
    "id": "a1",
    "title": "RISC-V Microservers Edge Past ARM in Ultra-Low Power AI Benchmarks",
    "url": "https://example.com/riscv-microservers",
    "source": "TechCrunch",
    "type": "news",
    "publishedAt": "2025-08-09T20:10:06Z",
    "summary": "Startups debut RISC-V microservers built for on-device LLM inference with sub-5W envelopes, targeting retail cameras and factory sensors.",
    "content": "A wave of RISC-V microservers focus on quantized transformer inference. Vendors claim 2x perf/W vs ARM on 7B parameter models. Integrations with MQTT and OPC-UA suggest industrial uptake.",
    "tickers": [
      "ARM",
      "NVDA"
    ],
    "companies": [
      "SiFive",
      "NVIDIA"
    ],
    "concepts": [
      "RISC-V",
      "microserver",
      "edge AI",
      "quantization",
      "transformer inference"
    ]
  },
  {
    "id": "a2",
    "title": "Liquid Neural Nets Jump to Robotics: Smoother Control with Fewer Params",
    "url": "https://example.com/liquid-nn-robotics",
    "source": "The Verge",
    "type": "news",
    "publishedAt": "2025-08-09T17:10:06Z",
    "summary": "Liquid neural networks tested on 6-DOF arms show smoother trajectories and quick adaptation to payload variations.",
    "content": "MIT-inspired liquid neural nets provide time-varying dynamics. Labs report robustness to noise and reduced compute needs, enabling cheaper controllers.",
    "tickers": [
      "IRBT"
    ],
    "companies": [
      "Boston Dynamics"
    ],
    "concepts": [
      "liquid neural nets",
      "robotics",
      "adaptive control"
    ]
  },
  {
    "id": "a3",
    "title": "Open-Source VLMs Get Vision-Long-Context via Patch-Token Compression",
    "url": "https://example.com/vlm-long-context",
    "source": "Hacker News",
    "type": "hackernews",
    "publishedAt": "2025-08-08T22:10:06Z",
    "summary": "A repo demonstrates patch-token compression for 8K-token images, enabling document QA on slides and posters.",
    "content": "The method compresses patches with learned adapters, bringing down vision context memory. Early adopters target medical imaging triage.",
    "tickers": [],
    "companies": [],
    "concepts": [
      "VLM",
      "token compression",
      "document QA"
    ]
  },
  {
    "id": "a4",
    "title": "YouTube: TinyML on ESP32-S3 Runs Keyword Spotting and Gesture Control",
    "url": "https://youtube.com/watch?v=dQw4w9WgXcQ",
    "source": "YouTube",
    "type": "youtube",
    "publishedAt": "2025-08-09T04:10:06Z",
    "summary": "A tutorial shows IMU gesture control + KWS on ESP32-S3 microcontrollers with < 300KB RAM footprint.",
    "content": "Combining IMU features and MFCCs, the demo hits 92% KWS accuracy indoors and drives a BLE device.",
    "tickers": [],
    "companies": [
      "Espressif"
    ],
    "concepts": [
      "TinyML",
      "ESP32",
      "gesture control"
    ]
  },
  {
    "id": "a5",
    "title": "Reddit: DIY Photonic Computing \u2014 Using MRRs for MAC Operations",
    "url": "https://reddit.com/r/optics",
    "source": "Reddit",
    "type": "reddit",
    "publishedAt": "2025-08-08T18:10:06Z",
    "summary": "Discussion explores microring resonators (MRRs) to perform analog matrix-vector multiplication for AI accelerators.",
    "content": "Hobbyists debate calibration drift and thermal stability; link budget remains a challenge for multi-chip scaling.",
    "tickers": [],
    "companies": [],
    "concepts": [
      "photonic computing",
      "MRR",
      "analog MAC"
    ]
  },
  {
    "id": "a6",
    "title": "Foundry Race Heats Up: HBM4 and CoWoS-R Timelines Slip for 3nm Nodes",
    "url": "https://example.com/foundry-hbm4-cowosr",
    "source": "Semiconductor Times",
    "type": "news",
    "publishedAt": "2025-08-09T14:10:06Z",
    "summary": "Vendors push HBM4 sampling while advanced packaging lines face throughput constraints.",
    "content": "CoWoS-R availability becomes the bottleneck for AI accelerator shipments, shifting capex to ABF substrate capacity.",
    "tickers": [
      "TSM",
      "MU",
      "AVGO"
    ],
    "companies": [
      "TSMC",
      "Micron",
      "Broadcom"
    ],
    "concepts": [
      "HBM4",
      "CoWoS-R",
      "advanced packaging"
    ]
  }
];
window.MOCK_PRICES = {
  "NVDA": [
    950,
    948,
    960,
    962,
    980,
    979,
    990,
    1002,
    998,
    1008,
    1020,
    1012
  ],
  "ARM": [
    168,
    170,
    172,
    171,
    173,
    175,
    176,
    177,
    175,
    178,
    180,
    179
  ],
  "AAPL": [
    214,
    215,
    213,
    216,
    217,
    219,
    221,
    220,
    222,
    224,
    225,
    226
  ],
  "TSM": [
    182,
    181,
    183,
    186,
    185,
    188,
    190,
    192,
    193,
    195,
    197,
    196
  ],
  "MU": [
    125,
    126,
    127,
    129,
    130,
    131,
    129,
    128,
    130,
    133,
    134,
    136
  ],
  "AVGO": [
    1730,
    1724,
    1735,
    1748,
    1759,
    1768,
    1772,
    1786,
    1791,
    1805,
    1810,
    1822
  ]
};
