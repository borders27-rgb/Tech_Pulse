
// Lightweight local storage wrapper
const Store = {
  get(key, def) {
    try { return JSON.parse(localStorage.getItem(key)) ?? def; }
    catch { return def; }
  },
  set(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
  }
};

const DEFAULT_SETTINGS = {
  demoMode: true,
  dark: true,
  sources: [
    { id: 'hn', name: 'Hacker News (front)', type: 'hackernews', url: 'https://hn.algolia.com/api/v1/search?tags=front_page' },
    { id: 'tc', name: 'TechCrunch RSS', type: 'news', url: 'https://techcrunch.com/feed/' },
    { id: 'verge', name: 'The Verge RSS', type: 'news', url: 'https://www.theverge.com/rss/index.xml' },
    { id: 'yt', name: 'YouTube: TinyML topic (sample)', type: 'youtube', url: 'https://www.youtube.com/results?search_query=tinyml' }
  ],
  alphaKey: '',
  llmEndpoint: '',
  llmKey: '',
  proxyUrl: ''
};

let settings = Store.get('settings', DEFAULT_SETTINGS);
let watchlist = Store.get('watchlist', ['NVDA', 'AAPL', 'ARM']);
let alerts = Store.get('alerts', [
  { id: 'alrt1', rule: { type: 'noveltyAbove', threshold: 70 }, active: true },
  { id: 'alrt2', rule: { type: 'priceJumpPct', ticker: 'NVDA', pct: 2.5 }, active: true }
]);

function saveSettings() { Store.set('settings', settings); }
function saveWatchlist() { Store.set('watchlist', watchlist); }
function saveAlerts() { Store.set('alerts', alerts); }

export { Store, settings, saveSettings, watchlist, saveWatchlist, alerts, saveAlerts, DEFAULT_SETTINGS };
