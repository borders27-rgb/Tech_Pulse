
import { settings } from './store.js';

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('HTTP '+res.status);
  return await res.json();
}

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('HTTP '+res.status);
  return await res.text();
}

function proxied(url) {
  if (settings.proxyUrl && !url.startsWith(settings.proxyUrl)) {
    return settings.proxyUrl + encodeURIComponent(url);
  }
  return url;
}

// --- Example connectors ---
// 1) Hacker News (Algolia API) - already JSON
async function getHackerNewsFront() {
  const url = 'https://hn.algolia.com/api/v1/search?tags=front_page';
  const data = await fetchJSON(proxied(url));
  return (data.hits || []).map(h => ({
    id: 'hn_'+h.objectID,
    title: h.title,
    url: h.url || ('https://news.ycombinator.com/item?id='+h.objectID),
    source: 'Hacker News',
    type: 'hackernews',
    publishedAt: h.created_at,
    summary: h._highlightResult && h._highlightResult.title ? h._highlightResult.title.value.replace(/<[^>]+>/g,'') : '',
    content: '',
    tickers: [], companies: [], concepts: []
  }));
}

// 2) Generic RSS via a VERY naive parser (requires CORS-friendly URL or a proxy)
async function getRSS(url, label='RSS') {
  const xml = await fetchText(proxied(url));
  const doc = new DOMParser().parseFromString(xml, 'text/xml');
  const items = [...doc.querySelectorAll('item')].slice(0, 20);
  return items.map((it, idx) => ({
    id: label+'_'+idx,
    title: it.querySelector('title')?.textContent || '(no title)',
    url: it.querySelector('link')?.textContent || '#',
    source: label,
    type: 'news',
    publishedAt: it.querySelector('pubDate')?.textContent || new Date().toISOString(),
    summary: it.querySelector('description')?.textContent || '',
    content: '',
    tickers: [], companies: [], concepts: []
  }));
}

// 3) YouTube — placeholder (search page HTML is not ideal for client scraping)
async function getYouTubePlaceholder() {
  return [{
    id: 'yt_demo',
    title: 'TinyML on ESP32-S3 Runs Keyword Spotting and Gesture Control',
    url: 'https://youtube.com/watch?v=dQw4w9WgXcQ',
    source: 'YouTube',
    type: 'youtube',
    publishedAt: new Date(Date.now()-20*60*60*1000).toISOString(),
    summary: 'Tutorial shows IMU gesture control + KWS on ESP32-S3 with <300KB RAM.',
    content: '',
    tickers: [], companies: ['Espressif'], concepts: ['TinyML','ESP32']
  }];
}

// 4) Alpha Vantage prices (optional, requires key; free tier is rate-limited)
async function getAlphaPrices(ticker) {
  if (!settings.alphaKey) return null;
  const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=${encodeURIComponent(ticker)}&apikey=${settings.alphaKey}&outputsize=compact`;
  try {
    const data = await fetchJSON(proxied(url));
    const ts = data['Time Series (Daily)'];
    if (!ts) return null;
    const entries = Object.entries(ts).sort((a,b)=> new Date(a[0]) - new Date(b[0]) );
    return entries.map(([date, o]) => Number(o['5. adjusted close']));
  } catch (e) {
    console.warn('Alpha Vantage error', e);
    return null;
  }
}

async function fetchAllEnabledSources() {
  const out = [];
  for (const s of settings.sources) {
    try {
      if (s.type === 'hackernews') {
        out.push(...await getHackerNewsFront());
      } else if (s.type === 'news') {
        out.push(...await getRSS(s.url, s.name));
      } else if (s.type === 'youtube') {
        out.push(...await getYouTubePlaceholder());
      }
    } catch (e) {
      console.warn('Source failed', s, e);
    }
  }
  return out;
}

export { fetchAllEnabledSources, getAlphaPrices };
