
import { settings, saveSettings, watchlist, saveWatchlist, alerts, saveAlerts } from './store.js';
import { noveltyScore } from './analyzers.js';

function $(sel, root=document) { return root.querySelector(sel); }
function $all(sel, root=document) { return [...root.querySelectorAll(sel)]; }

function setActiveView(view) {
  $all('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  $all('.view').forEach(v => v.classList.toggle('visible', v.id === 'view-'+view));
}

function setDark(on) {
  document.body.classList.toggle('light', !on);
}

function renderTrendCards(trends) {
  const cont = $('#trendSummary'); cont.innerHTML = '';
  const tmpl = $('#tmpl-trend-card');
  trends.forEach(t => {
    const node = tmpl.content.cloneNode(true);
    node.querySelector('.trend-title').textContent = t.label;
    node.querySelector('.trend-score').textContent = noveltyScore(t);
    node.querySelector('.trend-meta').textContent =
      `${t.items.length} articles • ${new Set(t.items.map(i => i.source)).size} sources`;
    const tags = node.querySelector('.trend-tags');
    [...(t.concepts||[]), ...(t.keywords||[])].slice(0,6).forEach(x => {
      const span = document.createElement('span'); span.className='tag'; span.textContent = x;
      tags.appendChild(span);
    });
    node.querySelector('.btn-watch').addEventListener('click', () => {
      t.tickers.forEach(tk => {
        if (!watchlist.includes(tk)) watchlist.push(tk);
      });
      saveWatchlist();
      alert('Added related tickers to watchlist (if any).');
    });
    cont.appendChild(node);
  });
}

function renderFeed(items) {
  const list = $('#feedList'); list.innerHTML = '';
  const tmpl = $('#tmpl-feed-item');
  items.forEach(a => {
    const node = tmpl.content.cloneNode(true);
    node.querySelector('.source-pill').textContent = a.source;
    const link = node.querySelector('.title');
    link.textContent = a.title; link.href = a.url;
    node.querySelector('.summary').textContent = a.summary || a.content?.slice(0,160) || '';
    const d = new Date(a.publishedAt);
    node.querySelector('.meta').textContent = `${d.toLocaleString()} • ${a.type}`;
    list.appendChild(node);
  });
}

function renderSources() {
  const list = $('#sourceList'); list.innerHTML = '';
  settings.sources.forEach((s) => {
    const row = document.createElement('div'); row.className='feed-item';
    row.innerHTML = \`
      <div class="source-pill">\${s.type}</div>
      <div><strong>\${s.name || s.id}</strong></div>
      <div class="meta small">\${s.url}</div>
      <div class="meta small">id: \${s.id}</div>
    \`;
    list.appendChild(row);
  });
}

function renderAlerts() {
  const list = $('#alertsList'); list.innerHTML = '';
  alerts.forEach(al => {
    const el = document.createElement('div'); el.className='alert-item';
    el.innerHTML = \`
      <div class="rule">\${JSON.stringify(al.rule)}</div>
      <div class="status small">\${al.active ? 'active' : 'paused'}</div>
      <div class="actions">
        <button class="btn btn-ghost btn-run">Run</button>
        <button class="btn btn-ghost btn-delete">Delete</button>
      </div>
    \`;
    el.querySelector('.btn-delete').addEventListener('click', () => {
      const i = alerts.findIndex(x => x.id===al.id); if (i>=0) { alerts.splice(i,1); saveAlerts(); renderAlerts(); }
    });
    el.querySelector('.btn-run').addEventListener('click', () => {
      document.dispatchEvent(new CustomEvent('run-alert-rule', { detail: al }));
    });
    list.appendChild(el);
  });
}

function renderWatchlist(pricesByTicker) {
  const grid = $('#watchlist'); grid.innerHTML = '';
  const tmpl = $('#tmpl-watch-card');
  watchlist.forEach(tk => {
    const node = tmpl.content.cloneNode(true);
    node.querySelector('.ticker').textContent = tk;
    node.querySelector('.btn-remove').addEventListener('click', () => {
      const idx = watchlist.indexOf(tk); if (idx>=0) { watchlist.splice(idx,1); saveWatchlist(); renderWatchlist(pricesByTicker); }
    });
    const ctx = node.querySelector('.priceChart');
    const series = (pricesByTicker[tk] || []).slice(-60);
    if (series.length) {
      new window.Chart(ctx, {
        type: 'line',
        data: {
          labels: series.map((_,i)=>i+1),
          datasets: [{ data: series, fill:false, tension:0.3, pointRadius:0 }]
        },
        options: {
          plugins: { legend: { display:false } },
          scales: { x: { display:false }, y: { display:false } },
          maintainAspectRatio: false
        }
      });
    } else {
      const msg = document.createElement('div');
      msg.className = 'small'; msg.textContent = 'No price data';
      node.querySelector('.priceChart').replaceWith(msg);
    }
    grid.appendChild(node);
  });
}

function bindChrome(app) {
  // Nav
  document.querySelectorAll('.nav-item').forEach(b => {
    b.addEventListener('click', () => setActiveView(b.dataset.view));
  });

  // Search
  $('#globalSearch').addEventListener('input', (e) => {
    app.onSearch?.(e.target.value);
  });

  // Dark mode
  const toggle = $('#toggleDark');
  toggle.checked = !!settings.dark;
  setDark(!!settings.dark);
  toggle.addEventListener('change', () => {
    settings.dark = toggle.checked; saveSettings(); setDark(settings.dark);
  });

  // Actions
  $('#refreshBtn').addEventListener('click', () => app.refresh?.());
  $('#demoBtn').addEventListener('click', () => app.toggleDemo?.());

  // Alerts
  $('#newAlertBtn').addEventListener('click', () => app.createAlert?.());
  $('#runAlertsBtn').addEventListener('click', () => app.runAlerts?.());

  // Watchlist
  $('#addTickerBtn').addEventListener('click', () => {
    const inp = $('#addTicker'); const v = (inp.value||'').trim().toUpperCase(); if (!v) return;
    if (!watchlist.includes(v)) { watchlist.push(v); saveWatchlist(); app.refresh?.(); }
    inp.value='';
  });

  // Settings
  $('#alphaKey').value = settings.alphaKey || '';
  $('#llmEndpoint').value = settings.llmEndpoint || '';
  $('#llmKey').value = settings.llmKey || '';
  $('#proxyUrl').value = settings.proxyUrl || '';
  $('#saveSettingsBtn').addEventListener('click', () => {
    settings.alphaKey = $('#alphaKey').value.trim();
    settings.llmEndpoint = $('#llmEndpoint').value.trim();
    settings.llmKey = $('#llmKey').value.trim();
    settings.proxyUrl = $('#proxyUrl').value.trim();
    saveSettings();
    alert('Settings saved.');
  });

  // Sources
  renderSources();
  $('#addSourceBtn').addEventListener('click', () => {
    const url = $('#newSourceUrl').value.trim();
    if (!url) return;
    settings.sources.push({ id: 'custom_'+Date.now(), name: 'Custom Feed', type: 'news', url });
    saveSettings(); renderSources(); $('#newSourceUrl').value='';
  });
}

export { renderTrendCards, renderFeed, renderWatchlist, renderAlerts, bindChrome };
